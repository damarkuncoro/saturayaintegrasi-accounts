--
-- PostgreSQL database dump
--

\restrict yPAk9GcfTPbIJ32ZrLf9h4k3QW28ECyl2Jtu4bi00q1bUaCTcG7p9UmuHalRNLd

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    allowed_ips character varying[] DEFAULT '{}'::character varying[],
    api_key character varying NOT NULL,
    api_secret_digest character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    expires_at timestamp(6) without time zone,
    last_used_at timestamp(6) without time zone,
    last_used_ip character varying,
    name character varying NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    rate_limit_per_minute integer DEFAULT 60,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.api_clients OWNER TO postgres;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action character varying NOT NULL,
    auditable_id uuid,
    auditable_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    ip_address character varying,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    ip_address character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_agent character varying,
    user_id uuid NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sso_client_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sso_client_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    allowed_scopes character varying[] DEFAULT '{openid,profile,email}'::character varying[] NOT NULL,
    client_id character varying NOT NULL,
    client_name character varying NOT NULL,
    client_secret_digest character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    redirect_uris character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.sso_client_configurations OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    domain character varying,
    name character varying NOT NULL,
    plan character varying DEFAULT 'starter'::character varying NOT NULL,
    slug character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trusted_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    device_fingerprint character varying NOT NULL,
    ip_address character varying,
    last_verified_at timestamp(6) without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_agent character varying,
    user_id uuid NOT NULL
);


ALTER TABLE public.trusted_devices OWNER TO postgres;

--
-- Name: user_consents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_consents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    consent_signature character varying NOT NULL,
    consented_scopes jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    granted_at timestamp(6) without time zone NOT NULL,
    revoked_at timestamp(6) without time zone,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.user_consents OWNER TO postgres;

--
-- Name: user_passkeys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_passkeys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    external_id character varying NOT NULL,
    nickname character varying,
    public_key character varying NOT NULL,
    sign_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.user_passkeys OWNER TO postgres;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action character varying,
    conditions jsonb,
    created_at timestamp(6) without time zone NOT NULL,
    resource_type character varying,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    email character varying NOT NULL,
    first_name character varying DEFAULT ''::character varying NOT NULL,
    last_name character varying DEFAULT ''::character varying NOT NULL,
    otp_required_for_login boolean DEFAULT false NOT NULL,
    otp_secret character varying,
    password_digest character varying NOT NULL,
    phone character varying DEFAULT ''::character varying NOT NULL,
    provider character varying,
    role integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    uid character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    username character varying,
    verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_clients (id, active, allowed_ips, api_key, api_secret_digest, created_at, expires_at, last_used_at, last_used_ip, name, permissions, rate_limit_per_minute, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2026-06-03 08:09:05.954968	2026-06-03 08:09:05.954977
schema_sha1	74c2fb158b8597802cff01e420a3083b92131ae9	2026-06-03 08:09:05.995983	2026-06-03 08:09:05.995988
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, action, auditable_id, auditable_type, created_at, ip_address, metadata, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20260602050000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, created_at, ip_address, updated_at, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: sso_client_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sso_client_configurations (id, active, allowed_scopes, client_id, client_name, client_secret_digest, created_at, redirect_uris, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, active, created_at, domain, name, plan, slug, updated_at) FROM stdin;
461b9693-1191-495a-8da9-bc08f6304d74	t	2026-06-03 08:09:07.934519	demo.satukerja.dev	Demo Company	starter	demo	2026-06-03 08:09:07.934519
2045749c-2375-45d0-a7fa-5e32eaa0cb9a	t	2026-06-03 08:09:08.232975	techcorp.satukerja.dev	TechCorp Indonesia	pro	techcorp	2026-06-03 08:09:08.232975
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trusted_devices (id, created_at, device_fingerprint, ip_address, last_verified_at, revoked, updated_at, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: user_consents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_consents (id, consent_signature, consented_scopes, created_at, granted_at, revoked_at, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: user_passkeys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_passkeys (id, created_at, external_id, nickname, public_key, sign_count, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (id, action, conditions, created_at, resource_type, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, active, created_at, email, first_name, last_name, otp_required_for_login, otp_secret, password_digest, phone, provider, role, tenant_id, uid, updated_at, username, verified) FROM stdin;
25bbd90f-41a3-4b15-95cf-6eccd351e42f	t	2026-06-03 08:09:09.030789	admin@demo.com	Admin	Demo	f	\N	$2a$12$VGP1e2eIhC1jahkzS2aWFesCI4s4UXm0egok3o32iNBsB6BLvo8OG		\N	2	461b9693-1191-495a-8da9-bc08f6304d74	\N	2026-06-03 08:09:09.030789	admin	t
\.


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_client_configurations sso_client_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sso_client_configurations
    ADD CONSTRAINT sso_client_configurations_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: user_consents user_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consents
    ADD CONSTRAINT user_consents_pkey PRIMARY KEY (id);


--
-- Name: user_passkeys user_passkeys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_passkeys
    ADD CONSTRAINT user_passkeys_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_api_clients_on_api_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_api_clients_on_api_key ON public.api_clients USING btree (api_key);


--
-- Name: index_api_clients_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_api_clients_on_tenant_id ON public.api_clients USING btree (tenant_id);


--
-- Name: index_audit_logs_on_auditable_type_and_auditable_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_auditable_type_and_auditable_id ON public.audit_logs USING btree (auditable_type, auditable_id);


--
-- Name: index_audit_logs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: index_audit_logs_on_tenant_id_and_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_tenant_id_and_created_at ON public.audit_logs USING btree (tenant_id, created_at);


--
-- Name: index_audit_logs_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: index_sessions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_sessions_on_user_id ON public.sessions USING btree (user_id);


--
-- Name: index_sso_client_configurations_on_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_sso_client_configurations_on_client_id ON public.sso_client_configurations USING btree (client_id);


--
-- Name: index_sso_client_configurations_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_sso_client_configurations_on_tenant_id ON public.sso_client_configurations USING btree (tenant_id);


--
-- Name: index_tenants_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_domain ON public.tenants USING btree (domain);


--
-- Name: index_tenants_on_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_slug ON public.tenants USING btree (slug);


--
-- Name: index_trusted_devices_on_device_fingerprint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_trusted_devices_on_device_fingerprint ON public.trusted_devices USING btree (device_fingerprint);


--
-- Name: index_trusted_devices_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_trusted_devices_on_user_id ON public.trusted_devices USING btree (user_id);


--
-- Name: index_user_consents_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_consents_on_tenant_id ON public.user_consents USING btree (tenant_id);


--
-- Name: index_user_consents_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_consents_on_user_id ON public.user_consents USING btree (user_id);


--
-- Name: index_user_consents_on_user_id_and_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_consents_on_user_id_and_tenant_id ON public.user_consents USING btree (user_id, tenant_id);


--
-- Name: index_user_passkeys_on_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_user_passkeys_on_external_id ON public.user_passkeys USING btree (external_id);


--
-- Name: index_user_passkeys_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_passkeys_on_user_id ON public.user_passkeys USING btree (user_id);


--
-- Name: index_user_permissions_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_permissions_on_tenant_id ON public.user_permissions USING btree (tenant_id);


--
-- Name: index_user_permissions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_permissions_on_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: index_user_permissions_on_user_resource_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_user_permissions_on_user_resource_action ON public.user_permissions USING btree (user_id, resource_type, action);


--
-- Name: index_users_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: index_users_on_tenant_id_and_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id_and_active ON public.users USING btree (tenant_id, active);


--
-- Name: index_users_on_tenant_id_and_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_tenant_id_and_email ON public.users USING btree (tenant_id, email);


--
-- Name: index_users_on_tenant_id_and_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id_and_role ON public.users USING btree (tenant_id, role);


--
-- Name: index_users_on_tenant_id_and_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id_and_verified ON public.users USING btree (tenant_id, verified);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_username ON public.users USING btree (username);


--
-- Name: user_passkeys fk_rails_0095e1bdca; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_passkeys
    ADD CONSTRAINT fk_rails_0095e1bdca FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs fk_rails_1f26bc34ae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_rails_1f26bc34ae FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sso_client_configurations fk_rails_28b2eccfbe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sso_client_configurations
    ADD CONSTRAINT fk_rails_28b2eccfbe FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: api_clients fk_rails_5f55d5ae3b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT fk_rails_5f55d5ae3b FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sessions fk_rails_758836b4f0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_rails_758836b4f0 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_permissions fk_rails_9400e1ca55; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT fk_rails_9400e1ca55 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: trusted_devices fk_rails_96c1dacf00; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT fk_rails_96c1dacf00 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_permissions fk_rails_b29e483ce4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT fk_rails_b29e483ce4 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_logs fk_rails_ecbd71e2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_rails_ecbd71e2ce FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: user_consents fk_rails_efd0aca7fc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consents
    ADD CONSTRAINT fk_rails_efd0aca7fc FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_consents fk_rails_efd51597b5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consents
    ADD CONSTRAINT fk_rails_efd51597b5 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict yPAk9GcfTPbIJ32ZrLf9h4k3QW28ECyl2Jtu4bi00q1bUaCTcG7p9UmuHalRNLd

