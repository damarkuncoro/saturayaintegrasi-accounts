--
-- PostgreSQL database dump
--

\restrict 2GsvKqqJK2h5sbW5LJrviBxOyZO2BKVEtZwrzYuRT18TlLJuRkkpjcR0sVcsGB6

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blob_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    record_id uuid NOT NULL,
    record_type character varying NOT NULL
);


ALTER TABLE public.active_storage_attachments OWNER TO postgres;

--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_blobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying NOT NULL,
    content_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    filename character varying NOT NULL,
    key character varying NOT NULL,
    metadata text,
    service_name character varying NOT NULL
);


ALTER TABLE public.active_storage_blobs OWNER TO postgres;

--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_variant_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blob_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    metadata text,
    variation_digest character varying NOT NULL
);


ALTER TABLE public.active_storage_variant_records OWNER TO postgres;

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    api_key character varying NOT NULL,
    api_secret_digest character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.api_clients OWNER TO postgres;

--
-- Name: application_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event_type character varying,
    job_application_id uuid NOT NULL,
    message text,
    metadata jsonb,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.application_logs OWNER TO postgres;

--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    end_date date,
    end_time time without time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    notes text,
    processed_at timestamp(6) without time zone,
    processed_by_id uuid,
    reason text,
    request_type integer DEFAULT 0 NOT NULL,
    start_date date,
    start_time time without time zone,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.approval_requests OWNER TO postgres;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: attendance_import_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attendance_source_id uuid NOT NULL,
    completed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    employer_profile_id uuid NOT NULL,
    error_summary text,
    failed_rows integer DEFAULT 0 NOT NULL,
    file_name character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp(6) without time zone,
    status integer DEFAULT 0 NOT NULL,
    success_rows integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    total_rows integer DEFAULT 0 NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    uploaded_by_id uuid NOT NULL
);


ALTER TABLE public.attendance_import_batches OWNER TO postgres;

--
-- Name: attendance_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    device_identifier character varying,
    employer_profile_id uuid NOT NULL,
    name character varying NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_type integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    vendor character varying,
    worksite_id uuid
);


ALTER TABLE public.attendance_sources OWNER TO postgres;

--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attendance_source_id uuid,
    clock_in_at timestamp(6) without time zone,
    clock_out_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    distance_from_site double precision,
    external_reference character varying,
    import_batch_id uuid,
    latitude_in double precision,
    latitude_out double precision,
    location_status integer DEFAULT 0,
    longitude_in double precision,
    longitude_out double precision,
    notes text,
    qr_code_token character varying,
    raw_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    shift_id uuid NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    verification_type integer,
    worker_profile_id uuid NOT NULL,
    source_device_id uuid,
    metadata jsonb
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action character varying NOT NULL,
    auditable_id uuid,
    auditable_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    ip_address character varying,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: competency_standards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_standards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    code character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    kbji_code character varying,
    sector character varying,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.competency_standards OWNER TO postgres;

--
-- Name: compliance_findings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_findings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text NOT NULL,
    employer_profile_id uuid NOT NULL,
    recommendation text,
    resolution_notes text,
    resolved_at timestamp(6) without time zone,
    severity integer DEFAULT 0,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.compliance_findings OWNER TO postgres;

--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text,
    contract_type integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    employer_profile_id uuid NOT NULL,
    end_date date,
    esign_metadata jsonb,
    is_nda boolean,
    job_application_id uuid NOT NULL,
    notes text,
    reminder_sent_at timestamp(6) without time zone,
    salary_amount numeric(15,2),
    shift_id uuid NOT NULL,
    signed_at timestamp(6) without time zone,
    start_date date,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: course_clicks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_clicks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    source character varying,
    tenant_id uuid NOT NULL,
    training_course_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.course_clicks OWNER TO postgres;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying,
    serial_number character varying,
    device_type character varying,
    status character varying,
    last_heartbeat_at timestamp(6) without time zone,
    metadata jsonb,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    document_type integer DEFAULT 0 NOT NULL,
    documentable_id uuid NOT NULL,
    documentable_type character varying NOT NULL,
    expires_at timestamp(6) without time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    verified_at timestamp(6) without time zone,
    verified_by_id uuid
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: employer_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employer_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    address character varying,
    auto_validation_report jsonb DEFAULT '{}'::jsonb NOT NULL,
    company_description text,
    company_name character varying NOT NULL,
    company_size character varying,
    compliance_score integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    industry character varying,
    tax_id character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL,
    verified boolean DEFAULT false,
    verified_compliance boolean DEFAULT false,
    verified_compliant boolean DEFAULT false,
    website character varying,
    tenant_id uuid
);


ALTER TABLE public.employer_profiles OWNER TO postgres;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    ends_at timestamp(6) without time zone,
    job_application_id uuid NOT NULL,
    location character varying,
    notes text,
    starts_at timestamp(6) without time zone,
    status integer,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.interviews OWNER TO postgres;

--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cover_letter text,
    created_at timestamp(6) without time zone NOT NULL,
    job_id uuid NOT NULL,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.job_applications OWNER TO postgres;

--
-- Name: job_competency_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_competency_requirements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    competency_standard_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    job_id uuid NOT NULL,
    mandatory boolean DEFAULT false,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.job_competency_requirements OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bpjs_kesehatan boolean,
    bpjs_ketenagakerjaan boolean,
    category character varying,
    compliance_agreed boolean DEFAULT false,
    created_at timestamp(6) without time zone NOT NULL,
    description text NOT NULL,
    employer_profile_id uuid NOT NULL,
    job_type integer DEFAULT 0,
    latitude double precision,
    location character varying,
    longitude double precision,
    max_salary numeric(15,2),
    min_salary numeric(15,2),
    minimum_wage_compliant boolean,
    requirements text,
    salary_range character varying,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    thr_guaranteed boolean,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    workplace_radius integer DEFAULT 100
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: kbji_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kbji_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    title character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    version character varying
);


ALTER TABLE public.kbji_roles OWNER TO postgres;

--
-- Name: kbki_commodities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kbki_commodities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying NOT NULL,
    commodity_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    level integer DEFAULT 0,
    parent_code character varying,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    version character varying
);


ALTER TABLE public.kbki_commodities OWNER TO postgres;

--
-- Name: kbli_sectors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kbli_sectors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    kbli_id character varying,
    last boolean DEFAULT false NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    parent_code character varying,
    parent_id character varying,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    version character varying
);


ALTER TABLE public.kbli_sectors OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text,
    created_at timestamp(6) without time zone NOT NULL,
    job_application_id uuid NOT NULL,
    read_at timestamp(6) without time zone,
    receiver_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: minimum_wages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.minimum_wages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    amount numeric(15,2) NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    region_name character varying NOT NULL,
    regulation_reference character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    year integer NOT NULL
);


ALTER TABLE public.minimum_wages OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event_type character varying,
    message text,
    notifiable_id uuid NOT NULL,
    notifiable_type character varying NOT NULL,
    read_at timestamp(6) without time zone,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: partners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    api_key character varying NOT NULL,
    contact_email character varying,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    status integer DEFAULT 0,
    updated_at timestamp(6) without time zone NOT NULL,
    website character varying
);


ALTER TABLE public.partners OWNER TO postgres;

--
-- Name: payroll_audit_trails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_audit_trails (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text NOT NULL,
    event_type character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    payroll_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.payroll_audit_trails OWNER TO postgres;

--
-- Name: payroll_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    amount numeric(15,2) NOT NULL,
    category integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    notes text,
    payroll_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.payroll_items OWNER TO postgres;

--
-- Name: payroll_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    end_date date NOT NULL,
    name character varying NOT NULL,
    processed_at timestamp(6) without time zone,
    processed_by_id uuid,
    start_date date NOT NULL,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    total_payout numeric DEFAULT 0.0,
    total_workers integer DEFAULT 0,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.payroll_periods OWNER TO postgres;

--
-- Name: payrolls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payrolls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    allowances numeric(15,2) DEFAULT 0.0 NOT NULL,
    base_salary numeric(15,2) NOT NULL,
    contract_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    deductions numeric(15,2) DEFAULT 0.0 NOT NULL,
    delay_days integer DEFAULT 0 NOT NULL,
    due_date date NOT NULL,
    late_fine_amount numeric(15,2) DEFAULT 0.0 NOT NULL,
    net_salary numeric(15,2) NOT NULL,
    notes text,
    overtime_hours integer DEFAULT 0 NOT NULL,
    overtime_pay numeric(15,2) DEFAULT 0.0 NOT NULL,
    payroll_period_id uuid,
    period_end date NOT NULL,
    period_start date NOT NULL,
    processed_at timestamp(6) without time zone,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.payrolls OWNER TO postgres;

--
-- Name: raw_attendance_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raw_attendance_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attendance_import_batch_id uuid,
    attendance_source_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event_time timestamp(6) without time zone NOT NULL,
    event_type integer DEFAULT 0 NOT NULL,
    external_device_id character varying,
    external_user_id character varying NOT NULL,
    matched_worker_profile_id uuid,
    processed boolean DEFAULT false NOT NULL,
    processing_error character varying,
    raw_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.raw_attendance_logs OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    ip_address character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_agent character varying,
    user_id uuid NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shifts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    end_time time without time zone,
    name character varying,
    start_time time without time zone,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    work_days integer DEFAULT 5 NOT NULL
);


ALTER TABLE public.shifts OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    domain character varying,
    name character varying NOT NULL,
    plan character varying DEFAULT 'starter'::character varying NOT NULL,
    slug character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: training_courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_courses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    clicks_count integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    duration character varying,
    kbji_code character varying NOT NULL,
    level character varying,
    partner_id uuid,
    price numeric(15,2) DEFAULT 0.0,
    provider_name character varying NOT NULL,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    url character varying
);


ALTER TABLE public.training_courses OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    amount numeric(15,2) NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    reference_id bigint,
    reference_type character varying,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    transaction_type integer NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    wallet_id uuid NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    resource_type character varying,
    action character varying,
    conditions jsonb,
    tenant_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    email character varying NOT NULL,
    first_name character varying DEFAULT ''::character varying NOT NULL,
    last_name character varying DEFAULT ''::character varying NOT NULL,
    password_digest character varying NOT NULL,
    phone character varying DEFAULT ''::character varying NOT NULL,
    role integer DEFAULT 0 NOT NULL,
    tenant_id uuid,
    updated_at timestamp(6) without time zone NOT NULL,
    username character varying,
    verified boolean DEFAULT false NOT NULL,
    uid character varying,
    provider character varying,
    otp_secret character varying,
    otp_required_for_login boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    balance numeric(15,2) DEFAULT 0.0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    currency character varying DEFAULT 'IDR'::character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.wallets OWNER TO postgres;

--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    duration_ms integer,
    error_message text,
    event_name character varying,
    payload jsonb,
    response_body text,
    response_code integer,
    status character varying,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    webhook_endpoint_id uuid NOT NULL
);


ALTER TABLE public.webhook_deliveries OWNER TO postgres;

--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook_endpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp(6) without time zone NOT NULL,
    events character varying[] DEFAULT '{}'::character varying[],
    secret character varying NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    url character varying NOT NULL
);


ALTER TABLE public.webhook_endpoints OWNER TO postgres;

--
-- Name: worker_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    contract_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    end_date date,
    notes text,
    shift_id uuid NOT NULL,
    start_date date NOT NULL,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL,
    worksite_id uuid NOT NULL
);


ALTER TABLE public.worker_assignments OWNER TO postgres;

--
-- Name: worker_attendance_identities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker_attendance_identities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    attendance_source_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    external_card_id character varying,
    external_user_id character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.worker_attendance_identities OWNER TO postgres;

--
-- Name: worker_competencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker_competencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    certificate_number character varying,
    certified boolean DEFAULT false,
    certified_at date,
    competency_standard_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    issuing_body character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.worker_competencies OWNER TO postgres;

--
-- Name: worker_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    availability character varying,
    available_for_work boolean DEFAULT true,
    bio text,
    created_at timestamp(6) without time zone NOT NULL,
    experience_years integer DEFAULT 0,
    hourly_rate numeric(10,2),
    kbji_code character varying,
    location character varying,
    reputation_score integer,
    skills jsonb DEFAULT '[]'::jsonb,
    trust_report jsonb,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL,
    verified boolean DEFAULT false,
    verified_identity boolean,
    tenant_id uuid
);


ALTER TABLE public.worker_profiles OWNER TO postgres;

--
-- Name: worksites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worksites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    address text,
    created_at timestamp(6) without time zone NOT NULL,
    employer_profile_id uuid NOT NULL,
    latitude double precision,
    longitude double precision,
    name character varying NOT NULL,
    radius_meters integer DEFAULT 100 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.worksites OWNER TO postgres;

--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_attachments (id, blob_id, created_at, name, record_id, record_type) FROM stdin;
\.


--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_blobs (id, byte_size, checksum, content_type, created_at, filename, key, metadata, service_name) FROM stdin;
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_variant_records (id, blob_id, created_at, metadata, variation_digest) FROM stdin;
\.


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_clients (id, active, api_key, api_secret_digest, created_at, name, permissions, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: application_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_logs (id, created_at, event_type, job_application_id, message, metadata, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_requests (id, created_at, end_date, end_time, metadata, notes, processed_at, processed_by_id, reason, request_type, start_date, start_time, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
schema_sha1	6d7e8e243b60612892035fb7b5b76d06f0daf88a	2026-05-25 16:06:01.368673	2026-05-25 16:06:01.368676
environment	development	2026-05-25 16:06:01.364031	2026-05-25 16:07:37.558478
\.


--
-- Data for Name: attendance_import_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance_import_batches (id, attendance_source_id, completed_at, created_at, employer_profile_id, error_summary, failed_rows, file_name, metadata, started_at, status, success_rows, tenant_id, total_rows, updated_at, uploaded_by_id) FROM stdin;
\.


--
-- Data for Name: attendance_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance_sources (id, active, created_at, device_identifier, employer_profile_id, name, settings, source_type, tenant_id, updated_at, vendor, worksite_id) FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (id, attendance_source_id, clock_in_at, clock_out_at, created_at, distance_from_site, external_reference, import_batch_id, latitude_in, latitude_out, location_status, longitude_in, longitude_out, notes, qr_code_token, raw_payload, shift_id, status, tenant_id, updated_at, verification_type, worker_profile_id, source_device_id, metadata) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, action, auditable_id, auditable_type, created_at, ip_address, metadata, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: competency_standards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_standards (id, active, code, created_at, description, kbji_code, sector, title, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_findings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_findings (id, category, created_at, description, employer_profile_id, recommendation, resolution_notes, resolved_at, severity, status, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (id, content, contract_type, created_at, employer_profile_id, end_date, esign_metadata, is_nda, job_application_id, notes, reminder_sent_at, salary_amount, shift_id, signed_at, start_date, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: course_clicks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_clicks (id, created_at, source, tenant_id, training_course_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devices (id, tenant_id, name, serial_number, device_type, status, last_heartbeat_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, created_at, description, document_type, documentable_id, documentable_type, expires_at, metadata, status, tenant_id, title, updated_at, verified_at, verified_by_id) FROM stdin;
\.


--
-- Data for Name: employer_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employer_profiles (id, active, address, auto_validation_report, company_description, company_name, company_size, compliance_score, created_at, industry, tax_id, updated_at, user_id, verified, verified_compliance, verified_compliant, website, tenant_id) FROM stdin;
5dd221e3-82e8-4b13-86fd-2852e63efec1	t	\N	{}	\N	Browser Demo Ops	1-10	0	2026-05-25 23:54:55.393701	C	\N	2026-05-25 23:54:55.393701	560dd063-181f-47c9-a4a9-07293572a8b2	t	f	f	\N	7c66aff8-4125-4cfe-baba-ca7ca836700f
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interviews (id, created_at, ends_at, job_application_id, location, notes, starts_at, status, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_applications (id, cover_letter, created_at, job_id, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: job_competency_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_competency_requirements (id, competency_standard_id, created_at, job_id, mandatory, updated_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, bpjs_kesehatan, bpjs_ketenagakerjaan, category, compliance_agreed, created_at, description, employer_profile_id, job_type, latitude, location, longitude, max_salary, min_salary, minimum_wage_compliant, requirements, salary_range, status, tenant_id, thr_guaranteed, title, updated_at, workplace_radius) FROM stdin;
\.


--
-- Data for Name: kbji_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kbji_roles (id, code, created_at, description, title, updated_at, version) FROM stdin;
\.


--
-- Data for Name: kbki_commodities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kbki_commodities (id, code, commodity_type, created_at, description, level, parent_code, title, updated_at, version) FROM stdin;
\.


--
-- Data for Name: kbli_sectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kbli_sectors (id, code, created_at, description, kbli_id, last, level, parent_code, parent_id, title, updated_at, version) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, content, created_at, job_application_id, read_at, receiver_id, sender_id, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: minimum_wages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.minimum_wages (id, amount, created_at, region_name, regulation_reference, updated_at, year) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, actor_id, created_at, event_type, message, notifiable_id, notifiable_type, read_at, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partners (id, active, api_key, contact_email, created_at, name, status, updated_at, website) FROM stdin;
\.


--
-- Data for Name: payroll_audit_trails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_audit_trails (id, created_at, description, event_type, metadata, payroll_id, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: payroll_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_items (id, amount, category, created_at, name, notes, payroll_id, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: payroll_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_periods (id, created_at, end_date, name, processed_at, processed_by_id, start_date, status, tenant_id, total_payout, total_workers, updated_at) FROM stdin;
\.


--
-- Data for Name: payrolls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payrolls (id, allowances, base_salary, contract_id, created_at, deductions, delay_days, due_date, late_fine_amount, net_salary, notes, overtime_hours, overtime_pay, payroll_period_id, period_end, period_start, processed_at, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: raw_attendance_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raw_attendance_logs (id, attendance_import_batch_id, attendance_source_id, created_at, event_time, event_type, external_device_id, external_user_id, matched_worker_profile_id, processed, processing_error, raw_payload, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20260525160218
20260525050000
20260525040000
20260525030000
20260525020000
20260525010000
20260525000000
20260524180000
20260524070000
20260524060000
20260524053144
20260524052235
20260524052224
20260524050458
20260524050001
20260524045953
20260524045944
20260524045257
20260524044303
20260524042557
20260524041834
20260523170000
20260523160000
20260523150000
20260523140000
20260523130000
20260523120000
20260523110000
20260523100000
20260523090000
20260523080000
20260523062600
20260523061513
20260522172846
20260522101055
20260522000000
20260521080616
20260521074609
20260521070001
20260521070000
20260521054706
20260521045347
20260521041447
20260516071836
20260516070644
20260515000001
20260515000000
20260513001500
20260513001000
20260513000000
20260512055000
20260512054513
20260512054455
20260512054321
20260512054320
20260525160718
20260525161135
20260525161655
20260525162505
20260525162544
20260525163104
20260525163502
20260526010000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, created_at, ip_address, updated_at, user_agent, user_id) FROM stdin;
565cc0f9-2555-4f86-9518-be82534aeca6	2026-05-25 23:55:09.667349	192.168.65.1	2026-05-25 23:55:09.667349	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Codex/26.519.41501 Chrome/148.0.7778.97 Electron/42.1.0 Safari/537.36	560dd063-181f-47c9-a4a9-07293572a8b2
1400d6b0-4453-4000-aca7-d17e2f06e6a3	2026-05-25 23:55:49.949722	192.168.65.1	2026-05-25 23:55:49.949722	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Codex/26.519.41501 Chrome/148.0.7778.97 Electron/42.1.0 Safari/537.36	560dd063-181f-47c9-a4a9-07293572a8b2
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shifts (id, active, created_at, end_time, name, start_time, tenant_id, updated_at, work_days) FROM stdin;
98af2102-53f3-4974-83b4-cf445f452410	t	2026-05-25 23:54:57.280604	10:00:00	Browser Shift	01:00:00	7c66aff8-4125-4cfe-baba-ca7ca836700f	2026-05-25 23:54:57.280604	5
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, active, created_at, domain, name, plan, slug, updated_at) FROM stdin;
7c66aff8-4125-4cfe-baba-ca7ca836700f	t	2026-05-25 23:54:54.867545	browser-demo.example.com	Browser Demo	starter	browser-demo	2026-05-25 23:54:54.867545
\.


--
-- Data for Name: training_courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_courses (id, active, clicks_count, created_at, description, duration, kbji_code, level, partner_id, price, provider_name, title, updated_at, url) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, amount, created_at, metadata, reference_id, reference_type, status, tenant_id, transaction_type, updated_at, wallet_id) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (id, user_id, resource_type, action, conditions, tenant_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, active, created_at, email, first_name, last_name, password_digest, phone, role, tenant_id, updated_at, username, verified, uid, provider, otp_secret, otp_required_for_login) FROM stdin;
560dd063-181f-47c9-a4a9-07293572a8b2	t	2026-05-25 23:54:55.227341	browser.employer@example.com	Browser	Employer	$2a$12$qKys/gOHJyhGvNZe16jiZ.svxVAoh6HQyHFchUhZbkgn4W7Yp11Py		1	7c66aff8-4125-4cfe-baba-ca7ca836700f	2026-05-25 23:54:55.227341	browseremployer	t	\N	\N	\N	f
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallets (id, balance, created_at, currency, status, tenant_id, updated_at, user_id) FROM stdin;
07e408c0-b737-4b87-80e2-e8e9e6d94456	0.00	2026-05-25 23:54:55.28356	IDR	0	7c66aff8-4125-4cfe-baba-ca7ca836700f	2026-05-25 23:54:55.28356	560dd063-181f-47c9-a4a9-07293572a8b2
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook_deliveries (id, created_at, duration_ms, error_message, event_name, payload, response_body, response_code, status, tenant_id, updated_at, webhook_endpoint_id) FROM stdin;
\.


--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook_endpoints (id, active, created_at, events, secret, tenant_id, updated_at, url) FROM stdin;
\.


--
-- Data for Name: worker_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker_assignments (id, active, contract_id, created_at, end_date, notes, shift_id, start_date, status, tenant_id, updated_at, worker_profile_id, worksite_id) FROM stdin;
\.


--
-- Data for Name: worker_attendance_identities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker_attendance_identities (id, active, attendance_source_id, created_at, external_card_id, external_user_id, metadata, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: worker_competencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker_competencies (id, certificate_number, certified, certified_at, competency_standard_id, created_at, issuing_body, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: worker_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker_profiles (id, availability, available_for_work, bio, created_at, experience_years, hourly_rate, kbji_code, location, reputation_score, skills, trust_report, updated_at, user_id, verified, verified_identity, tenant_id) FROM stdin;
\.


--
-- Data for Name: worksites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worksites (id, active, address, created_at, employer_profile_id, latitude, longitude, name, radius_meters, tenant_id, updated_at) FROM stdin;
\.


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: api_clients api_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT api_clients_pkey PRIMARY KEY (id);


--
-- Name: application_logs application_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT application_logs_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attendance_import_batches attendance_import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_import_batches
    ADD CONSTRAINT attendance_import_batches_pkey PRIMARY KEY (id);


--
-- Name: attendance_sources attendance_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sources
    ADD CONSTRAINT attendance_sources_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: competency_standards competency_standards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_standards
    ADD CONSTRAINT competency_standards_pkey PRIMARY KEY (id);


--
-- Name: compliance_findings compliance_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_findings
    ADD CONSTRAINT compliance_findings_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: course_clicks course_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_clicks
    ADD CONSTRAINT course_clicks_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: employer_profiles employer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_profiles
    ADD CONSTRAINT employer_profiles_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- Name: job_competency_requirements job_competency_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_competency_requirements
    ADD CONSTRAINT job_competency_requirements_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: kbji_roles kbji_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kbji_roles
    ADD CONSTRAINT kbji_roles_pkey PRIMARY KEY (id);


--
-- Name: kbki_commodities kbki_commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kbki_commodities
    ADD CONSTRAINT kbki_commodities_pkey PRIMARY KEY (id);


--
-- Name: kbli_sectors kbli_sectors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kbli_sectors
    ADD CONSTRAINT kbli_sectors_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: minimum_wages minimum_wages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.minimum_wages
    ADD CONSTRAINT minimum_wages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: payroll_audit_trails payroll_audit_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_audit_trails
    ADD CONSTRAINT payroll_audit_trails_pkey PRIMARY KEY (id);


--
-- Name: payroll_items payroll_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT payroll_items_pkey PRIMARY KEY (id);


--
-- Name: payroll_periods payroll_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);


--
-- Name: payrolls payrolls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT payrolls_pkey PRIMARY KEY (id);


--
-- Name: raw_attendance_logs raw_attendance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_attendance_logs
    ADD CONSTRAINT raw_attendance_logs_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: training_courses training_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_courses
    ADD CONSTRAINT training_courses_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: worker_assignments worker_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT worker_assignments_pkey PRIMARY KEY (id);


--
-- Name: worker_attendance_identities worker_attendance_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_attendance_identities
    ADD CONSTRAINT worker_attendance_identities_pkey PRIMARY KEY (id);


--
-- Name: worker_competencies worker_competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_competencies
    ADD CONSTRAINT worker_competencies_pkey PRIMARY KEY (id);


--
-- Name: worker_profiles worker_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_profiles
    ADD CONSTRAINT worker_profiles_pkey PRIMARY KEY (id);


--
-- Name: worksites worksites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksites
    ADD CONSTRAINT worksites_pkey PRIMARY KEY (id);


--
-- Name: idx_raw_attendance_logs_dedupe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_raw_attendance_logs_dedupe ON public.raw_attendance_logs USING btree (tenant_id, attendance_source_id, external_user_id, event_time);


--
-- Name: idx_worker_assignments_active_search; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_worker_assignments_active_search ON public.worker_assignments USING btree (tenant_id, worker_profile_id, active);


--
-- Name: idx_worker_attendance_identities_uniq_profile; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_worker_attendance_identities_uniq_profile ON public.worker_attendance_identities USING btree (tenant_id, worker_profile_id, attendance_source_id);


--
-- Name: idx_worker_attendance_identities_uniq_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_worker_attendance_identities_uniq_user ON public.worker_attendance_identities USING btree (tenant_id, attendance_source_id, external_user_id);


--
-- Name: idx_worker_comp_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_worker_comp_unique ON public.worker_competencies USING btree (worker_profile_id, competency_standard_id);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_on_blob_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_active_storage_variant_records_on_blob_id ON public.active_storage_variant_records USING btree (blob_id);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_api_clients_on_api_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_api_clients_on_api_key ON public.api_clients USING btree (api_key);


--
-- Name: index_api_clients_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_api_clients_on_tenant_id ON public.api_clients USING btree (tenant_id);


--
-- Name: index_application_logs_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_application_logs_on_job_application_id ON public.application_logs USING btree (job_application_id);


--
-- Name: index_application_logs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_application_logs_on_tenant_id ON public.application_logs USING btree (tenant_id);


--
-- Name: index_approval_requests_on_processed_by_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_approval_requests_on_processed_by_id ON public.approval_requests USING btree (processed_by_id);


--
-- Name: index_approval_requests_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_approval_requests_on_tenant_id ON public.approval_requests USING btree (tenant_id);


--
-- Name: index_approval_requests_on_tenant_id_and_request_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_approval_requests_on_tenant_id_and_request_type ON public.approval_requests USING btree (tenant_id, request_type);


--
-- Name: index_approval_requests_on_tenant_id_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_approval_requests_on_tenant_id_and_status ON public.approval_requests USING btree (tenant_id, status);


--
-- Name: index_approval_requests_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_approval_requests_on_worker_profile_id ON public.approval_requests USING btree (worker_profile_id);


--
-- Name: index_attendance_import_batches_on_attendance_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_import_batches_on_attendance_source_id ON public.attendance_import_batches USING btree (attendance_source_id);


--
-- Name: index_attendance_import_batches_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_import_batches_on_employer_profile_id ON public.attendance_import_batches USING btree (employer_profile_id);


--
-- Name: index_attendance_import_batches_on_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_import_batches_on_status ON public.attendance_import_batches USING btree (status);


--
-- Name: index_attendance_import_batches_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_import_batches_on_tenant_id ON public.attendance_import_batches USING btree (tenant_id);


--
-- Name: index_attendance_import_batches_on_uploaded_by_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_import_batches_on_uploaded_by_id ON public.attendance_import_batches USING btree (uploaded_by_id);


--
-- Name: index_attendance_sources_on_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_sources_on_active ON public.attendance_sources USING btree (active);


--
-- Name: index_attendance_sources_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_sources_on_employer_profile_id ON public.attendance_sources USING btree (employer_profile_id);


--
-- Name: index_attendance_sources_on_source_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_sources_on_source_type ON public.attendance_sources USING btree (source_type);


--
-- Name: index_attendance_sources_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_sources_on_tenant_id ON public.attendance_sources USING btree (tenant_id);


--
-- Name: index_attendance_sources_on_worksite_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendance_sources_on_worksite_id ON public.attendance_sources USING btree (worksite_id);


--
-- Name: index_attendances_on_attendance_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_attendance_source_id ON public.attendances USING btree (attendance_source_id);


--
-- Name: index_attendances_on_import_batch_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_import_batch_id ON public.attendances USING btree (import_batch_id);


--
-- Name: index_attendances_on_location_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_location_status ON public.attendances USING btree (location_status);


--
-- Name: index_attendances_on_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_shift_id ON public.attendances USING btree (shift_id);


--
-- Name: index_attendances_on_source_device_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_source_device_id ON public.attendances USING btree (source_device_id);


--
-- Name: index_attendances_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_tenant_id ON public.attendances USING btree (tenant_id);


--
-- Name: index_attendances_on_worker_profile_and_clock_in_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_worker_profile_and_clock_in_at ON public.attendances USING btree (worker_profile_id, clock_in_at);


--
-- Name: index_attendances_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_worker_profile_id ON public.attendances USING btree (worker_profile_id);


--
-- Name: index_audit_logs_on_auditable_type_and_auditable_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_auditable_type_and_auditable_id ON public.audit_logs USING btree (auditable_type, auditable_id);


--
-- Name: index_audit_logs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: index_audit_logs_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_audit_logs_on_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: index_competency_standards_on_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_competency_standards_on_code ON public.competency_standards USING btree (code);


--
-- Name: index_competency_standards_on_kbji_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_competency_standards_on_kbji_code ON public.competency_standards USING btree (kbji_code);


--
-- Name: index_competency_standards_on_sector; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_competency_standards_on_sector ON public.competency_standards USING btree (sector);


--
-- Name: index_compliance_findings_on_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_compliance_findings_on_category ON public.compliance_findings USING btree (category);


--
-- Name: index_compliance_findings_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_compliance_findings_on_employer_profile_id ON public.compliance_findings USING btree (employer_profile_id);


--
-- Name: index_compliance_findings_on_employer_profile_id_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_compliance_findings_on_employer_profile_id_and_status ON public.compliance_findings USING btree (employer_profile_id, status);


--
-- Name: index_compliance_findings_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_compliance_findings_on_tenant_id ON public.compliance_findings USING btree (tenant_id);


--
-- Name: index_contracts_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_employer_profile_id ON public.contracts USING btree (employer_profile_id);


--
-- Name: index_contracts_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_job_application_id ON public.contracts USING btree (job_application_id);


--
-- Name: index_contracts_on_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_shift_id ON public.contracts USING btree (shift_id);


--
-- Name: index_contracts_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_tenant_id ON public.contracts USING btree (tenant_id);


--
-- Name: index_contracts_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_worker_profile_id ON public.contracts USING btree (worker_profile_id);


--
-- Name: index_course_clicks_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_course_clicks_on_tenant_id ON public.course_clicks USING btree (tenant_id);


--
-- Name: index_course_clicks_on_training_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_course_clicks_on_training_course_id ON public.course_clicks USING btree (training_course_id);


--
-- Name: index_course_clicks_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_course_clicks_on_worker_profile_id ON public.course_clicks USING btree (worker_profile_id);


--
-- Name: index_devices_on_serial_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_devices_on_serial_number ON public.devices USING btree (serial_number);


--
-- Name: index_devices_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_devices_on_tenant_id ON public.devices USING btree (tenant_id);


--
-- Name: index_documents_on_document_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_document_type ON public.documents USING btree (document_type);


--
-- Name: index_documents_on_documentable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_documentable ON public.documents USING btree (documentable_type, documentable_id);


--
-- Name: index_documents_on_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_expires_at ON public.documents USING btree (expires_at);


--
-- Name: index_documents_on_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_metadata ON public.documents USING gin (metadata);


--
-- Name: index_documents_on_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_status ON public.documents USING btree (status);


--
-- Name: index_documents_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_tenant_id ON public.documents USING btree (tenant_id);


--
-- Name: index_documents_on_verified_by_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_documents_on_verified_by_id ON public.documents USING btree (verified_by_id);


--
-- Name: index_employer_profiles_on_company_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_company_name ON public.employer_profiles USING btree (company_name);


--
-- Name: index_employer_profiles_on_industry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_industry ON public.employer_profiles USING btree (industry);


--
-- Name: index_employer_profiles_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_tenant_id ON public.employer_profiles USING btree (tenant_id);


--
-- Name: index_employer_profiles_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_user_id ON public.employer_profiles USING btree (user_id);


--
-- Name: index_employer_profiles_on_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_verified ON public.employer_profiles USING btree (verified);


--
-- Name: index_employer_profiles_on_verified_compliant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_verified_compliant ON public.employer_profiles USING btree (verified_compliant);


--
-- Name: index_interviews_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_interviews_on_job_application_id ON public.interviews USING btree (job_application_id);


--
-- Name: index_interviews_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_interviews_on_tenant_id ON public.interviews USING btree (tenant_id);


--
-- Name: index_job_applications_on_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_job_id ON public.job_applications USING btree (job_id);


--
-- Name: index_job_applications_on_job_id_and_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_job_applications_on_job_id_and_worker_profile_id ON public.job_applications USING btree (job_id, worker_profile_id);


--
-- Name: index_job_applications_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_tenant_id ON public.job_applications USING btree (tenant_id);


--
-- Name: index_job_applications_on_tenant_id_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_tenant_id_and_status ON public.job_applications USING btree (tenant_id, status);


--
-- Name: index_job_applications_on_worker_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_worker_and_status ON public.job_applications USING btree (worker_profile_id, status);


--
-- Name: index_job_applications_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_worker_profile_id ON public.job_applications USING btree (worker_profile_id);


--
-- Name: index_job_competency_requirements_on_competency_standard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_competency_requirements_on_competency_standard_id ON public.job_competency_requirements USING btree (competency_standard_id);


--
-- Name: index_job_competency_requirements_on_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_competency_requirements_on_job_id ON public.job_competency_requirements USING btree (job_id);


--
-- Name: index_jobs_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_employer_profile_id ON public.jobs USING btree (employer_profile_id);


--
-- Name: index_jobs_on_min_salary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_min_salary ON public.jobs USING btree (min_salary);


--
-- Name: index_jobs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_tenant_id ON public.jobs USING btree (tenant_id);


--
-- Name: index_jobs_on_tenant_id_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_tenant_id_and_status ON public.jobs USING btree (tenant_id, status);


--
-- Name: index_kbji_roles_on_code_and_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_kbji_roles_on_code_and_version ON public.kbji_roles USING btree (code, version);


--
-- Name: index_kbki_commodities_on_code_and_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_kbki_commodities_on_code_and_version ON public.kbki_commodities USING btree (code, version);


--
-- Name: index_kbki_commodities_on_commodity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_kbki_commodities_on_commodity_type ON public.kbki_commodities USING btree (commodity_type);


--
-- Name: index_kbli_sectors_on_code_and_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_kbli_sectors_on_code_and_version ON public.kbli_sectors USING btree (code, version);


--
-- Name: index_kbli_sectors_on_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_kbli_sectors_on_level ON public.kbli_sectors USING btree (level);


--
-- Name: index_kbli_sectors_on_parent_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_kbli_sectors_on_parent_code ON public.kbli_sectors USING btree (parent_code);


--
-- Name: index_messages_on_job_app_and_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_job_app_and_created_at ON public.messages USING btree (job_application_id, created_at);


--
-- Name: index_messages_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_job_application_id ON public.messages USING btree (job_application_id);


--
-- Name: index_messages_on_receiver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_receiver_id ON public.messages USING btree (receiver_id);


--
-- Name: index_messages_on_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_sender_id ON public.messages USING btree (sender_id);


--
-- Name: index_messages_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_tenant_id ON public.messages USING btree (tenant_id);


--
-- Name: index_minimum_wages_on_region_name_and_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_minimum_wages_on_region_name_and_year ON public.minimum_wages USING btree (region_name, year);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_event_type ON public.notifications USING btree (event_type);


--
-- Name: index_notifications_on_notifiable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_notifiable ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: index_notifications_on_read_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_read_at ON public.notifications USING btree (read_at);


--
-- Name: index_notifications_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_tenant_id ON public.notifications USING btree (tenant_id);


--
-- Name: index_notifications_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_user_id ON public.notifications USING btree (user_id);


--
-- Name: index_notifications_on_user_id_and_read_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_user_id_and_read_at ON public.notifications USING btree (user_id, read_at);


--
-- Name: index_partners_on_api_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_partners_on_api_key ON public.partners USING btree (api_key);


--
-- Name: index_payroll_audit_trails_on_payroll_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payroll_audit_trails_on_payroll_id ON public.payroll_audit_trails USING btree (payroll_id);


--
-- Name: index_payroll_audit_trails_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payroll_audit_trails_on_tenant_id ON public.payroll_audit_trails USING btree (tenant_id);


--
-- Name: index_payroll_items_on_payroll_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payroll_items_on_payroll_id ON public.payroll_items USING btree (payroll_id);


--
-- Name: index_payroll_items_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payroll_items_on_tenant_id ON public.payroll_items USING btree (tenant_id);


--
-- Name: index_payroll_periods_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payroll_periods_on_tenant_id ON public.payroll_periods USING btree (tenant_id);


--
-- Name: index_payrolls_on_contract_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_contract_id ON public.payrolls USING btree (contract_id);


--
-- Name: index_payrolls_on_payroll_period_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_payroll_period_id ON public.payrolls USING btree (payroll_period_id);


--
-- Name: index_payrolls_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_tenant_id ON public.payrolls USING btree (tenant_id);


--
-- Name: index_payrolls_on_worker_and_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_worker_and_period ON public.payrolls USING btree (worker_profile_id, period_start, period_end);


--
-- Name: index_payrolls_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_worker_profile_id ON public.payrolls USING btree (worker_profile_id);


--
-- Name: index_raw_attendance_logs_on_attendance_import_batch_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_attendance_import_batch_id ON public.raw_attendance_logs USING btree (attendance_import_batch_id);


--
-- Name: index_raw_attendance_logs_on_attendance_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_attendance_source_id ON public.raw_attendance_logs USING btree (attendance_source_id);


--
-- Name: index_raw_attendance_logs_on_event_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_event_time ON public.raw_attendance_logs USING btree (event_time);


--
-- Name: index_raw_attendance_logs_on_matched_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_matched_worker_profile_id ON public.raw_attendance_logs USING btree (matched_worker_profile_id);


--
-- Name: index_raw_attendance_logs_on_processed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_processed ON public.raw_attendance_logs USING btree (processed);


--
-- Name: index_raw_attendance_logs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_raw_attendance_logs_on_tenant_id ON public.raw_attendance_logs USING btree (tenant_id);


--
-- Name: index_sessions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_sessions_on_user_id ON public.sessions USING btree (user_id);


--
-- Name: index_shifts_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_shifts_on_tenant_id ON public.shifts USING btree (tenant_id);


--
-- Name: index_tenants_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_domain ON public.tenants USING btree (domain);


--
-- Name: index_tenants_on_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_slug ON public.tenants USING btree (slug);


--
-- Name: index_training_courses_on_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_training_courses_on_active ON public.training_courses USING btree (active);


--
-- Name: index_training_courses_on_kbji_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_training_courses_on_kbji_code ON public.training_courses USING btree (kbji_code);


--
-- Name: index_training_courses_on_partner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_training_courses_on_partner_id ON public.training_courses USING btree (partner_id);


--
-- Name: index_transactions_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_transactions_on_tenant_id ON public.transactions USING btree (tenant_id);


--
-- Name: index_transactions_on_wallet_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_transactions_on_wallet_id ON public.transactions USING btree (wallet_id);


--
-- Name: index_user_permissions_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_permissions_on_tenant_id ON public.user_permissions USING btree (tenant_id);


--
-- Name: index_user_permissions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_permissions_on_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: index_user_permissions_on_user_resource_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_user_permissions_on_user_resource_action ON public.user_permissions USING btree (user_id, resource_type, action);


--
-- Name: index_users_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: index_users_on_tenant_id_and_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_tenant_id_and_email ON public.users USING btree (tenant_id, email);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_username ON public.users USING btree (username);


--
-- Name: index_wallets_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_wallets_on_tenant_id ON public.wallets USING btree (tenant_id);


--
-- Name: index_wallets_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_wallets_on_user_id ON public.wallets USING btree (user_id);


--
-- Name: index_webhook_deliveries_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_webhook_deliveries_on_tenant_id ON public.webhook_deliveries USING btree (tenant_id);


--
-- Name: index_webhook_deliveries_on_webhook_endpoint_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_webhook_deliveries_on_webhook_endpoint_id ON public.webhook_deliveries USING btree (webhook_endpoint_id);


--
-- Name: index_webhook_endpoints_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_webhook_endpoints_on_tenant_id ON public.webhook_endpoints USING btree (tenant_id);


--
-- Name: index_worker_assignments_on_contract_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_contract_id ON public.worker_assignments USING btree (contract_id);


--
-- Name: index_worker_assignments_on_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_shift_id ON public.worker_assignments USING btree (shift_id);


--
-- Name: index_worker_assignments_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_tenant_id ON public.worker_assignments USING btree (tenant_id);


--
-- Name: index_worker_assignments_on_tenant_id_and_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_tenant_id_and_status ON public.worker_assignments USING btree (tenant_id, status);


--
-- Name: index_worker_assignments_on_tenant_id_and_worksite_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_tenant_id_and_worksite_id ON public.worker_assignments USING btree (tenant_id, worksite_id);


--
-- Name: index_worker_assignments_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_worker_profile_id ON public.worker_assignments USING btree (worker_profile_id);


--
-- Name: index_worker_assignments_on_worksite_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_assignments_on_worksite_id ON public.worker_assignments USING btree (worksite_id);


--
-- Name: index_worker_attendance_identities_on_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_attendance_identities_on_active ON public.worker_attendance_identities USING btree (active);


--
-- Name: index_worker_attendance_identities_on_attendance_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_attendance_identities_on_attendance_source_id ON public.worker_attendance_identities USING btree (attendance_source_id);


--
-- Name: index_worker_attendance_identities_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_attendance_identities_on_tenant_id ON public.worker_attendance_identities USING btree (tenant_id);


--
-- Name: index_worker_attendance_identities_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_attendance_identities_on_worker_profile_id ON public.worker_attendance_identities USING btree (worker_profile_id);


--
-- Name: index_worker_competencies_on_competency_standard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_competencies_on_competency_standard_id ON public.worker_competencies USING btree (competency_standard_id);


--
-- Name: index_worker_competencies_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_competencies_on_worker_profile_id ON public.worker_competencies USING btree (worker_profile_id);


--
-- Name: index_worker_profiles_on_availability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_availability ON public.worker_profiles USING btree (availability);


--
-- Name: index_worker_profiles_on_available_for_work; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_available_for_work ON public.worker_profiles USING btree (available_for_work);


--
-- Name: index_worker_profiles_on_kbji_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_kbji_code ON public.worker_profiles USING btree (kbji_code);


--
-- Name: index_worker_profiles_on_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_location ON public.worker_profiles USING btree (location);


--
-- Name: index_worker_profiles_on_skills; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_skills ON public.worker_profiles USING gin (skills);


--
-- Name: index_worker_profiles_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_tenant_id ON public.worker_profiles USING btree (tenant_id);


--
-- Name: index_worker_profiles_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_user_id ON public.worker_profiles USING btree (user_id);


--
-- Name: index_worker_profiles_on_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_verified ON public.worker_profiles USING btree (verified);


--
-- Name: index_worksites_on_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worksites_on_active ON public.worksites USING btree (active);


--
-- Name: index_worksites_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worksites_on_employer_profile_id ON public.worksites USING btree (employer_profile_id);


--
-- Name: index_worksites_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worksites_on_tenant_id ON public.worksites USING btree (tenant_id);


--
-- Name: index_worksites_on_tenant_id_and_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worksites_on_tenant_id_and_employer_profile_id ON public.worksites USING btree (tenant_id, employer_profile_id);


--
-- Name: interviews fk_rails_00ebd5b653; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT fk_rails_00ebd5b653 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: job_applications fk_rails_06cf44c042; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_06cf44c042 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: compliance_findings fk_rails_0b48f6bd1b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_findings
    ADD CONSTRAINT fk_rails_0b48f6bd1b FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: course_clicks fk_rails_0fc76d102c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_clicks
    ADD CONSTRAINT fk_rails_0fc76d102c FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: attendance_import_batches fk_rails_1427961ca1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_import_batches
    ADD CONSTRAINT fk_rails_1427961ca1 FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: contracts fk_rails_166779c930; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_166779c930 FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: worker_assignments fk_rails_16aa8b02ae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT fk_rails_16aa8b02ae FOREIGN KEY (worksite_id) REFERENCES public.worksites(id);


--
-- Name: attendances fk_rails_1a8e2a0250; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_1a8e2a0250 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: audit_logs fk_rails_1f26bc34ae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_rails_1f26bc34ae FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payrolls fk_rails_2993fc79bb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_2993fc79bb FOREIGN KEY (payroll_period_id) REFERENCES public.payroll_periods(id);


--
-- Name: approval_requests fk_rails_2e2f89e0fb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_rails_2e2f89e0fb FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: job_competency_requirements fk_rails_32d65127eb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_competency_requirements
    ADD CONSTRAINT fk_rails_32d65127eb FOREIGN KEY (competency_standard_id) REFERENCES public.competency_standards(id);


--
-- Name: webhook_deliveries fk_rails_392378d371; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT fk_rails_392378d371 FOREIGN KEY (webhook_endpoint_id) REFERENCES public.webhook_endpoints(id);


--
-- Name: attendances fk_rails_3bf5795c1d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_3bf5795c1d FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: jobs fk_rails_3fbd580f09; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_rails_3fbd580f09 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: application_logs fk_rails_43f33fe904; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT fk_rails_43f33fe904 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: raw_attendance_logs fk_rails_495d168cbc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_attendance_logs
    ADD CONSTRAINT fk_rails_495d168cbc FOREIGN KEY (attendance_import_batch_id) REFERENCES public.attendance_import_batches(id);


--
-- Name: worker_attendance_identities fk_rails_510fc871d8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_attendance_identities
    ADD CONSTRAINT fk_rails_510fc871d8 FOREIGN KEY (attendance_source_id) REFERENCES public.attendance_sources(id);


--
-- Name: attendance_import_batches fk_rails_54186bbd94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_import_batches
    ADD CONSTRAINT fk_rails_54186bbd94 FOREIGN KEY (uploaded_by_id) REFERENCES public.users(id);


--
-- Name: contracts fk_rails_599befa731; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_599befa731 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: approval_requests fk_rails_5a174479aa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_rails_5a174479aa FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: application_logs fk_rails_5c249055c1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT fk_rails_5c249055c1 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: documents fk_rails_5ca55da786; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT fk_rails_5ca55da786 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: api_clients fk_rails_5f55d5ae3b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_clients
    ADD CONSTRAINT fk_rails_5f55d5ae3b FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: raw_attendance_logs fk_rails_6204e72bb8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_attendance_logs
    ADD CONSTRAINT fk_rails_6204e72bb8 FOREIGN KEY (attendance_source_id) REFERENCES public.attendance_sources(id);


--
-- Name: attendance_sources fk_rails_62d38df66b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sources
    ADD CONSTRAINT fk_rails_62d38df66b FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: attendance_sources fk_rails_66644e5e59; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sources
    ADD CONSTRAINT fk_rails_66644e5e59 FOREIGN KEY (worksite_id) REFERENCES public.worksites(id);


--
-- Name: messages fk_rails_67c67d2963; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_67c67d2963 FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: contracts fk_rails_6b839060a3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_6b839060a3 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: attendance_sources fk_rails_6d77f7c560; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_sources
    ADD CONSTRAINT fk_rails_6d77f7c560 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: messages fk_rails_6e19b67e8c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_6e19b67e8c FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: attendances fk_rails_6ed520129e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_6ed520129e FOREIGN KEY (attendance_source_id) REFERENCES public.attendance_sources(id);


--
-- Name: attendance_import_batches fk_rails_6fae9bbafd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_import_batches
    ADD CONSTRAINT fk_rails_6fae9bbafd FOREIGN KEY (attendance_source_id) REFERENCES public.attendance_sources(id);


--
-- Name: wallets fk_rails_732f6628c4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT fk_rails_732f6628c4 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payrolls fk_rails_73acacc813; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_73acacc813 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payroll_periods fk_rails_75663765cc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT fk_rails_75663765cc FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sessions fk_rails_758836b4f0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_rails_758836b4f0 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: raw_attendance_logs fk_rails_7ae1426e1c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_attendance_logs
    ADD CONSTRAINT fk_rails_7ae1426e1c FOREIGN KEY (matched_worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: worker_assignments fk_rails_7b32189da2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT fk_rails_7b32189da2 FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: webhook_deliveries fk_rails_7c0bbfdb0c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT fk_rails_7c0bbfdb0c FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: attendances fk_rails_7c4e1eb782; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_7c4e1eb782 FOREIGN KEY (import_batch_id) REFERENCES public.attendance_import_batches(id);


--
-- Name: notifications fk_rails_7c99fe0556; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_7c99fe0556 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: transactions fk_rails_819d2cd6db; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_rails_819d2cd6db FOREIGN KEY (wallet_id) REFERENCES public.wallets(id);


--
-- Name: job_applications fk_rails_82b18fab66; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_82b18fab66 FOREIGN KEY (job_id) REFERENCES public.jobs(id);


--
-- Name: worker_competencies fk_rails_83928ebacb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_competencies
    ADD CONSTRAINT fk_rails_83928ebacb FOREIGN KEY (competency_standard_id) REFERENCES public.competency_standards(id);


--
-- Name: payrolls fk_rails_85992ba4c1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_85992ba4c1 FOREIGN KEY (contract_id) REFERENCES public.contracts(id);


--
-- Name: raw_attendance_logs fk_rails_869977e85a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_attendance_logs
    ADD CONSTRAINT fk_rails_869977e85a FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: webhook_endpoints fk_rails_8f26c71f58; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT fk_rails_8f26c71f58 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: shifts fk_rails_8fee8071f4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT fk_rails_8fee8071f4 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: user_permissions fk_rails_9400e1ca55; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT fk_rails_9400e1ca55 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: attendance_import_batches fk_rails_9bcd7d8855; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_import_batches
    ADD CONSTRAINT fk_rails_9bcd7d8855 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: worker_profiles fk_rails_a2fff7c7ea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_profiles
    ADD CONSTRAINT fk_rails_a2fff7c7ea FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: worker_assignments fk_rails_a6ce014ccc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT fk_rails_a6ce014ccc FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: transactions fk_rails_a7d1102541; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_rails_a7d1102541 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: employer_profiles fk_rails_a7d6158cd2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_profiles
    ADD CONSTRAINT fk_rails_a7d6158cd2 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payroll_items fk_rails_a92f33d03a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT fk_rails_a92f33d03a FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: job_competency_requirements fk_rails_ae71330280; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_competency_requirements
    ADD CONSTRAINT fk_rails_ae71330280 FOREIGN KEY (job_id) REFERENCES public.jobs(id);


--
-- Name: worksites fk_rails_afd5fb6ba5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksites
    ADD CONSTRAINT fk_rails_afd5fb6ba5 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: notifications fk_rails_b080fb4855; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_b080fb4855 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: compliance_findings fk_rails_b124361760; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_findings
    ADD CONSTRAINT fk_rails_b124361760 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: user_permissions fk_rails_b29e483ce4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT fk_rails_b29e483ce4 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: course_clicks fk_rails_b2a5dc3f69; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_clicks
    ADD CONSTRAINT fk_rails_b2a5dc3f69 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: contracts fk_rails_b598f6f9e0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_b598f6f9e0 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: attendances fk_rails_b7c6f9525c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_b7c6f9525c FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: messages fk_rails_b8f26a382d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_b8f26a382d FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: attendances fk_rails_c412a2ac56; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_c412a2ac56 FOREIGN KEY (source_device_id) REFERENCES public.devices(id);


--
-- Name: worksites fk_rails_c614400cb1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksites
    ADD CONSTRAINT fk_rails_c614400cb1 FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: employer_profiles fk_rails_cab8544d84; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_profiles
    ADD CONSTRAINT fk_rails_cab8544d84 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: worker_attendance_identities fk_rails_cb4729eb72; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_attendance_identities
    ADD CONSTRAINT fk_rails_cb4729eb72 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: wallets fk_rails_cc9a9ef272; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT fk_rails_cc9a9ef272 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: worker_assignments fk_rails_d1e9314f81; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT fk_rails_d1e9314f81 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: course_clicks fk_rails_d52b5ac380; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_clicks
    ADD CONSTRAINT fk_rails_d52b5ac380 FOREIGN KEY (training_course_id) REFERENCES public.training_courses(id);


--
-- Name: devices fk_rails_d5b7012cbc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT fk_rails_d5b7012cbc FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: worker_competencies fk_rails_d5e2924702; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_competencies
    ADD CONSTRAINT fk_rails_d5e2924702 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: job_applications fk_rails_d91727589f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_d91727589f FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: jobs fk_rails_da9195c942; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_rails_da9195c942 FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: worker_attendance_identities fk_rails_dbafe34e9e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_attendance_identities
    ADD CONSTRAINT fk_rails_dbafe34e9e FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: worker_assignments fk_rails_e293c4617c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_assignments
    ADD CONSTRAINT fk_rails_e293c4617c FOREIGN KEY (contract_id) REFERENCES public.contracts(id);


--
-- Name: contracts fk_rails_e4027c08ca; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_e4027c08ca FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: worker_profiles fk_rails_e6dc79b993; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_profiles
    ADD CONSTRAINT fk_rails_e6dc79b993 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payroll_items fk_rails_eac58412c2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT fk_rails_eac58412c2 FOREIGN KEY (payroll_id) REFERENCES public.payrolls(id);


--
-- Name: messages fk_rails_eadecc2ae1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_eadecc2ae1 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: interviews fk_rails_eaf899c37c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT fk_rails_eaf899c37c FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_logs fk_rails_ecbd71e2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_rails_ecbd71e2ce FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payrolls fk_rails_f83df09ea9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_f83df09ea9 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 2GsvKqqJK2h5sbW5LJrviBxOyZO2BKVEtZwrzYuRT18TlLJuRkkpjcR0sVcsGB6

