--
-- PostgreSQL database dump
--

\restrict FyznHSA4GlbSQHF63OQT8F51dL0tqcBkf6RS19EnYabfE3Hozgj6g5u9MDiOLaL

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blob_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    record_id uuid NOT NULL,
    record_type character varying NOT NULL
);


ALTER TABLE public.active_storage_attachments OWNER TO postgres;

--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_blobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying NOT NULL,
    content_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    filename character varying NOT NULL,
    key character varying NOT NULL,
    metadata text,
    service_name character varying NOT NULL
);


ALTER TABLE public.active_storage_blobs OWNER TO postgres;

--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_variant_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blob_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    metadata text,
    variation_digest character varying NOT NULL
);


ALTER TABLE public.active_storage_variant_records OWNER TO postgres;

--
-- Name: application_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event_type character varying,
    job_application_id uuid NOT NULL,
    message text,
    metadata jsonb,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.application_logs OWNER TO postgres;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clock_in_at timestamp(6) without time zone,
    clock_out_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    latitude_in double precision,
    latitude_out double precision,
    longitude_in double precision,
    longitude_out double precision,
    notes text,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text,
    contract_type integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    employer_profile_id uuid NOT NULL,
    end_date date,
    job_application_id uuid NOT NULL,
    salary_amount numeric(15,2),
    signed_at timestamp(6) without time zone,
    start_date date,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: employer_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employer_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true,
    address character varying,
    company_description text,
    company_name character varying NOT NULL,
    company_size character varying,
    created_at timestamp(6) without time zone NOT NULL,
    industry character varying,
    tax_id character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL,
    verified boolean DEFAULT false,
    verified_compliance boolean DEFAULT false,
    website character varying
);


ALTER TABLE public.employer_profiles OWNER TO postgres;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    ends_at timestamp(6) without time zone,
    job_application_id uuid NOT NULL,
    location character varying,
    notes text,
    starts_at timestamp(6) without time zone,
    status integer,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.interviews OWNER TO postgres;

--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cover_letter text,
    created_at timestamp(6) without time zone NOT NULL,
    job_id uuid NOT NULL,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.job_applications OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bpjs_kesehatan boolean,
    bpjs_ketenagakerjaan boolean,
    category character varying,
    compliance_agreed boolean DEFAULT false,
    created_at timestamp(6) without time zone NOT NULL,
    description text NOT NULL,
    employer_profile_id uuid NOT NULL,
    job_type integer DEFAULT 0,
    location character varying,
    minimum_wage_compliant boolean,
    requirements text,
    salary_range character varying,
    status integer DEFAULT 0,
    tenant_id uuid NOT NULL,
    thr_guaranteed boolean,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    latitude double precision,
    longitude double precision,
    workplace_radius integer DEFAULT 100
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text,
    created_at timestamp(6) without time zone NOT NULL,
    job_application_id uuid NOT NULL,
    read_at timestamp(6) without time zone,
    receiver_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event_type character varying,
    message text,
    notifiable_id uuid NOT NULL,
    notifiable_type character varying NOT NULL,
    read_at timestamp(6) without time zone,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: payrolls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payrolls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    allowances numeric(15,2) DEFAULT 0.0 NOT NULL,
    base_salary numeric(15,2) NOT NULL,
    contract_id uuid NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    deductions numeric(15,2) DEFAULT 0.0 NOT NULL,
    net_salary numeric(15,2) NOT NULL,
    period_end date NOT NULL,
    period_start date NOT NULL,
    processed_at timestamp(6) without time zone,
    status integer DEFAULT 0 NOT NULL,
    tenant_id uuid NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    worker_profile_id uuid NOT NULL
);


ALTER TABLE public.payrolls OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    ip_address character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_agent character varying,
    user_id uuid NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    domain character varying,
    name character varying NOT NULL,
    plan character varying DEFAULT 'starter'::character varying NOT NULL,
    slug character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    email character varying NOT NULL,
    first_name character varying DEFAULT ''::character varying NOT NULL,
    last_name character varying DEFAULT ''::character varying NOT NULL,
    password_digest character varying NOT NULL,
    phone character varying DEFAULT ''::character varying NOT NULL,
    role integer DEFAULT 0 NOT NULL,
    tenant_id uuid,
    updated_at timestamp(6) without time zone NOT NULL,
    username character varying,
    verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: worker_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worker_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    availability character varying,
    available_for_work boolean DEFAULT true,
    bio text,
    created_at timestamp(6) without time zone NOT NULL,
    experience_years integer DEFAULT 0,
    hourly_rate numeric(10,2),
    location character varying,
    skills jsonb DEFAULT '[]'::jsonb,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id uuid NOT NULL,
    verified boolean DEFAULT false
);


ALTER TABLE public.worker_profiles OWNER TO postgres;

--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_attachments (id, blob_id, created_at, name, record_id, record_type) FROM stdin;
\.


--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_blobs (id, byte_size, checksum, content_type, created_at, filename, key, metadata, service_name) FROM stdin;
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_variant_records (id, blob_id, created_at, metadata, variation_digest) FROM stdin;
\.


--
-- Data for Name: application_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_logs (id, created_at, event_type, job_application_id, message, metadata, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
schema_sha1	db09914aa7dc482e1fe00e10d6b04a9814662d98	2026-05-22 09:45:26.168796	2026-05-22 09:45:26.168799
environment	test	2026-05-22 03:04:51.272296	2026-05-22 10:11:17.403322
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (id, clock_in_at, clock_out_at, created_at, latitude_in, latitude_out, longitude_in, longitude_out, notes, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (id, content, contract_type, created_at, employer_profile_id, end_date, job_application_id, salary_amount, signed_at, start_date, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: employer_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employer_profiles (id, active, address, company_description, company_name, company_size, created_at, industry, tax_id, updated_at, user_id, verified, verified_compliance, website) FROM stdin;
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interviews (id, created_at, ends_at, job_application_id, location, notes, starts_at, status, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_applications (id, cover_letter, created_at, job_id, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, bpjs_kesehatan, bpjs_ketenagakerjaan, category, compliance_agreed, created_at, description, employer_profile_id, job_type, location, minimum_wage_compliant, requirements, salary_range, status, tenant_id, thr_guaranteed, title, updated_at, latitude, longitude, workplace_radius) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, content, created_at, job_application_id, read_at, receiver_id, sender_id, tenant_id, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, actor_id, created_at, event_type, message, notifiable_id, notifiable_type, read_at, tenant_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: payrolls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payrolls (id, allowances, base_salary, contract_id, created_at, deductions, net_salary, period_end, period_start, processed_at, status, tenant_id, updated_at, worker_profile_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20260512054320
20260512054321
20260512054455
20260512054513
20260512055000
20260513000000
20260513001000
20260513001500
20260515000000
20260515000001
20260516070644
20260516071836
20260521041447
20260521045347
20260521054706
20260521070000
20260521070001
20260521074609
20260521080616
20260522000000
20260522101055
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, created_at, ip_address, updated_at, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, active, created_at, domain, name, plan, slug, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, active, created_at, email, first_name, last_name, password_digest, phone, role, tenant_id, updated_at, username, verified) FROM stdin;
\.


--
-- Data for Name: worker_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worker_profiles (id, availability, available_for_work, bio, created_at, experience_years, hourly_rate, location, skills, updated_at, user_id, verified) FROM stdin;
\.


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: application_logs application_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT application_logs_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: employer_profiles employer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_profiles
    ADD CONSTRAINT employer_profiles_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payrolls payrolls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT payrolls_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: worker_profiles worker_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_profiles
    ADD CONSTRAINT worker_profiles_pkey PRIMARY KEY (id);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_on_blob_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_active_storage_variant_records_on_blob_id ON public.active_storage_variant_records USING btree (blob_id);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_application_logs_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_application_logs_on_job_application_id ON public.application_logs USING btree (job_application_id);


--
-- Name: index_application_logs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_application_logs_on_tenant_id ON public.application_logs USING btree (tenant_id);


--
-- Name: index_attendances_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_tenant_id ON public.attendances USING btree (tenant_id);


--
-- Name: index_attendances_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_attendances_on_worker_profile_id ON public.attendances USING btree (worker_profile_id);


--
-- Name: index_contracts_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_employer_profile_id ON public.contracts USING btree (employer_profile_id);


--
-- Name: index_contracts_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_job_application_id ON public.contracts USING btree (job_application_id);


--
-- Name: index_contracts_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_tenant_id ON public.contracts USING btree (tenant_id);


--
-- Name: index_contracts_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_contracts_on_worker_profile_id ON public.contracts USING btree (worker_profile_id);


--
-- Name: index_employer_profiles_on_company_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_company_name ON public.employer_profiles USING btree (company_name);


--
-- Name: index_employer_profiles_on_industry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_industry ON public.employer_profiles USING btree (industry);


--
-- Name: index_employer_profiles_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_user_id ON public.employer_profiles USING btree (user_id);


--
-- Name: index_employer_profiles_on_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_employer_profiles_on_verified ON public.employer_profiles USING btree (verified);


--
-- Name: index_interviews_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_interviews_on_job_application_id ON public.interviews USING btree (job_application_id);


--
-- Name: index_interviews_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_interviews_on_tenant_id ON public.interviews USING btree (tenant_id);


--
-- Name: index_job_applications_on_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_job_id ON public.job_applications USING btree (job_id);


--
-- Name: index_job_applications_on_job_id_and_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_job_applications_on_job_id_and_worker_profile_id ON public.job_applications USING btree (job_id, worker_profile_id);


--
-- Name: index_job_applications_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_tenant_id ON public.job_applications USING btree (tenant_id);


--
-- Name: index_job_applications_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_job_applications_on_worker_profile_id ON public.job_applications USING btree (worker_profile_id);


--
-- Name: index_jobs_on_employer_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_employer_profile_id ON public.jobs USING btree (employer_profile_id);


--
-- Name: index_jobs_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_jobs_on_tenant_id ON public.jobs USING btree (tenant_id);


--
-- Name: index_messages_on_job_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_job_application_id ON public.messages USING btree (job_application_id);


--
-- Name: index_messages_on_receiver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_receiver_id ON public.messages USING btree (receiver_id);


--
-- Name: index_messages_on_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_sender_id ON public.messages USING btree (sender_id);


--
-- Name: index_messages_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_messages_on_tenant_id ON public.messages USING btree (tenant_id);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_event_type ON public.notifications USING btree (event_type);


--
-- Name: index_notifications_on_notifiable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_notifiable ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: index_notifications_on_read_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_read_at ON public.notifications USING btree (read_at);


--
-- Name: index_notifications_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_tenant_id ON public.notifications USING btree (tenant_id);


--
-- Name: index_notifications_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_user_id ON public.notifications USING btree (user_id);


--
-- Name: index_payrolls_on_contract_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_contract_id ON public.payrolls USING btree (contract_id);


--
-- Name: index_payrolls_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_tenant_id ON public.payrolls USING btree (tenant_id);


--
-- Name: index_payrolls_on_worker_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_payrolls_on_worker_profile_id ON public.payrolls USING btree (worker_profile_id);


--
-- Name: index_sessions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_sessions_on_user_id ON public.sessions USING btree (user_id);


--
-- Name: index_tenants_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_domain ON public.tenants USING btree (domain);


--
-- Name: index_tenants_on_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tenants_on_slug ON public.tenants USING btree (slug);


--
-- Name: index_users_on_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: index_users_on_tenant_id_and_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_tenant_id_and_email ON public.users USING btree (tenant_id, email);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_username ON public.users USING btree (username);


--
-- Name: index_worker_profiles_on_availability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_availability ON public.worker_profiles USING btree (availability);


--
-- Name: index_worker_profiles_on_available_for_work; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_available_for_work ON public.worker_profiles USING btree (available_for_work);


--
-- Name: index_worker_profiles_on_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_location ON public.worker_profiles USING btree (location);


--
-- Name: index_worker_profiles_on_skills; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_skills ON public.worker_profiles USING gin (skills);


--
-- Name: index_worker_profiles_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_user_id ON public.worker_profiles USING btree (user_id);


--
-- Name: index_worker_profiles_on_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_worker_profiles_on_verified ON public.worker_profiles USING btree (verified);


--
-- Name: interviews fk_rails_00ebd5b653; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT fk_rails_00ebd5b653 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: job_applications fk_rails_06cf44c042; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_06cf44c042 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: attendances fk_rails_1a8e2a0250; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_1a8e2a0250 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: attendances fk_rails_3bf5795c1d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT fk_rails_3bf5795c1d FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: jobs fk_rails_3fbd580f09; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_rails_3fbd580f09 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: application_logs fk_rails_43f33fe904; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT fk_rails_43f33fe904 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: contracts fk_rails_599befa731; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_599befa731 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: application_logs fk_rails_5c249055c1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_logs
    ADD CONSTRAINT fk_rails_5c249055c1 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: messages fk_rails_67c67d2963; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_67c67d2963 FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: contracts fk_rails_6b839060a3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_6b839060a3 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: messages fk_rails_6e19b67e8c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_6e19b67e8c FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payrolls fk_rails_73acacc813; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_73acacc813 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sessions fk_rails_758836b4f0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_rails_758836b4f0 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications fk_rails_7c99fe0556; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_7c99fe0556 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: job_applications fk_rails_82b18fab66; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_82b18fab66 FOREIGN KEY (job_id) REFERENCES public.jobs(id);


--
-- Name: payrolls fk_rails_85992ba4c1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_85992ba4c1 FOREIGN KEY (contract_id) REFERENCES public.contracts(id);


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: worker_profiles fk_rails_a2fff7c7ea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worker_profiles
    ADD CONSTRAINT fk_rails_a2fff7c7ea FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications fk_rails_b080fb4855; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_b080fb4855 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contracts fk_rails_b598f6f9e0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_b598f6f9e0 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: messages fk_rails_b8f26a382d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_b8f26a382d FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: employer_profiles fk_rails_cab8544d84; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_profiles
    ADD CONSTRAINT fk_rails_cab8544d84 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: job_applications fk_rails_d91727589f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT fk_rails_d91727589f FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- Name: jobs fk_rails_da9195c942; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_rails_da9195c942 FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: contracts fk_rails_e4027c08ca; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_rails_e4027c08ca FOREIGN KEY (employer_profile_id) REFERENCES public.employer_profiles(id);


--
-- Name: messages fk_rails_eadecc2ae1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_eadecc2ae1 FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id);


--
-- Name: interviews fk_rails_eaf899c37c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT fk_rails_eaf899c37c FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: payrolls fk_rails_f83df09ea9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT fk_rails_f83df09ea9 FOREIGN KEY (worker_profile_id) REFERENCES public.worker_profiles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict FyznHSA4GlbSQHF63OQT8F51dL0tqcBkf6RS19EnYabfE3Hozgj6g5u9MDiOLaL

